/*==================================================
    PRELOADER
==================================================*/

window.addEventListener("load", function () {

    const preloader = document.querySelector(".preloader");

    if (preloader) {

        preloader.style.opacity = "0";

        setTimeout(() => {

            preloader.style.display = "none";

        }, 500);

    }

});

/*==================================================
    STICKY HEADER
==================================================*/

const header = document.querySelector(".header");

window.addEventListener("scroll", function () {

    if (window.scrollY > 80) {

        header.classList.add("sticky");

    } else {

        header.classList.remove("sticky");

    }

});

/*==================================================
    SMOOTH SCROLL
==================================================*/

document.querySelectorAll('a[href^="#"]').forEach(anchor => {

    anchor.addEventListener("click", function (e) {

        const target = document.querySelector(this.getAttribute("href"));

        if (!target) return;

        e.preventDefault();

        window.scrollTo({

            top: target.offsetTop - 70,

            behavior: "smooth"

        });

    });

});

/*==================================================
    ACTIVE MENU
==================================================*/

const sections = document.querySelectorAll("section");

const navLinks = document.querySelectorAll(".navbar-nav .nav-link");

window.addEventListener("scroll", () => {

    let current = "";

    sections.forEach(section => {

        const top = section.offsetTop - 120;

        const height = section.offsetHeight;

        if (pageYOffset >= top && pageYOffset < top + height) {

            current = section.getAttribute("id");

        }

    });

    navLinks.forEach(link => {

        link.classList.remove("active");

        if (link.getAttribute("href") === "#" + current) {

            link.classList.add("active");

        }

    });

});

/*==================================================
    MOBILE MENU CLOSE
==================================================*/

const navItems = document.querySelectorAll(".navbar-collapse .nav-link");

const navbar = document.querySelector(".navbar-collapse");

navItems.forEach(item => {

    item.addEventListener("click", () => {

        if (navbar.classList.contains("show")) {

            bootstrap.Collapse.getInstance(navbar).hide();

        }

    });

});

/*==================================================
    SCROLL TO TOP BUTTON
==================================================*/

const scrollBtn = document.createElement("div");

scrollBtn.className = "scroll-top";

scrollBtn.innerHTML = '<i class="fa-solid fa-arrow-up"></i>';

document.body.appendChild(scrollBtn);

window.addEventListener("scroll", () => {

    if (window.scrollY > 400) {

        scrollBtn.classList.add("active");

    } else {

        scrollBtn.classList.remove("active");

    }

});

scrollBtn.onclick = () => {

    window.scrollTo({

        top: 0,

        behavior: "smooth"

    });

};

/*==================================================
    SCROLL REVEAL
==================================================*/

const revealElements = document.querySelectorAll(

    ".process-box, .gallery-item, .counter-box, #about img, #about .col-lg-6"

);

const reveal = () => {

    const trigger = window.innerHeight - 120;

    revealElements.forEach(el => {

        const top = el.getBoundingClientRect().top;

        if (top < trigger) {

            el.classList.add("fade-up", "active");

        }

    });

};

window.addEventListener("scroll", reveal);

window.addEventListener("load", reveal);

/*==================================================
    COUNTER ANIMATION
==================================================*/

const counters = document.querySelectorAll(".counter-number");

const speed = 200;

const runCounter = () => {

    counters.forEach(counter => {

        const target = +counter.dataset.target;

        const count = +counter.innerText;

        const increment = target / speed;

        if (count < target) {

            counter.innerText = Math.ceil(count + increment);

            setTimeout(runCounter, 15);

        } else {

            counter.innerText = target;

        }

    });

};

const counterSection = document.querySelector(".counter");

if (counterSection) {

    const observer = new IntersectionObserver(entries => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                runCounter();

                observer.disconnect();

            }

        });

    });

    observer.observe(counterSection);

}

/*==================================================
    GALLERY HOVER
==================================================*/

document.querySelectorAll("#works img").forEach(img => {

    img.addEventListener("mouseenter", () => {

        img.style.transform = "scale(1.08)";

    });

    img.addEventListener("mouseleave", () => {

        img.style.transform = "scale(1)";

    });

});

/*==================================================
    CONTACT FORM VALIDATION
==================================================*/

const form = document.querySelector("form");

if (form) {

    form.addEventListener("submit", function (e) {

        e.preventDefault();

        const inputs = form.querySelectorAll("input, textarea");

        let valid = true;

        inputs.forEach(input => {

            if (input.value.trim() === "") {

                input.style.borderColor = "red";

                valid = false;

            } else {

                input.style.borderColor = "#ddd";

            }

        });

        if (valid) {

            alert("Thank you! Your message has been sent successfully.");

            form.reset();

        }

    });

}

/*==================================================
    IMAGE LAZY LOADING
==================================================*/

const lazyImages = document.querySelectorAll("img");

const imageObserver = new IntersectionObserver((entries, observer) => {

    entries.forEach(entry => {

        if (entry.isIntersecting) {

            const img = entry.target;

            img.classList.add("loaded");

            observer.unobserve(img);

        }

    });

});

lazyImages.forEach(img => {

    imageObserver.observe(img);

});

/*==================================================
    CURRENT YEAR
==================================================*/

const year = document.querySelector("#year");

if (year) {

    year.innerHTML = new Date().getFullYear();

}

/*==================================================
    PARALLAX HERO
==================================================*/

window.addEventListener("scroll", () => {

    const hero = document.querySelector(".hero");

    if (!hero) return;

    hero.style.backgroundPositionY = window.pageYOffset * 0.4 + "px";

});

/*==================================================
    BUTTON RIPPLE EFFECT
==================================================*/

document.querySelectorAll(".btn").forEach(button => {

    button.addEventListener("click", function (e) {

        const ripple = document.createElement("span");

        const diameter = Math.max(this.clientWidth, this.clientHeight);

        ripple.style.width = ripple.style.height = diameter + "px";

        ripple.style.left = e.offsetX - diameter / 2 + "px";

        ripple.style.top = e.offsetY - diameter / 2 + "px";

        ripple.classList.add("ripple");

        this.appendChild(ripple);

        setTimeout(() => {

            ripple.remove();

        }, 600);

    });

});

var swiper = new Swiper(".countrySlider", {

    loop:true,

    speed:900,

    autoplay:{

        delay:3500,

        disableOnInteraction:false,

    },

    spaceBetween:30,

    slidesPerView:4,

    pagination:{

        el:".swiper-pagination",

        clickable:true,

    },

    navigation:{

        nextEl:".swiper-button-next",

        prevEl:".swiper-button-prev",

    },

    breakpoints:{

        0:{

            slidesPerView:1,

        },

        576:{

            slidesPerView:2,

        },

        992:{

            slidesPerView:3,

        },

        1200:{

            slidesPerView:4,

        }

    }

});

<!-- ==============================================================
     SCROLL-REVEAL SCRIPT
     Adds .revealed to .step-card elements as they enter the viewport.
     Uses IntersectionObserver — no dependencies needed.
============================================================== -->

  (function () {
    var cards = document.querySelectorAll('.step-card');
    if (!cards.length) return;

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });

    cards.forEach(function (card) {
      observer.observe(card);
    });
  })();

/*==================================================
    CONSOLE MESSAGE
==================================================*/

console.log(
    "%cGlobal Visa Consultancy Website Loaded Successfully",
    "color:#0B4F9C;font-size:16px;font-weight:bold;"
);